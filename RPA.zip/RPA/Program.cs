﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp2
{   
    class Program
    {
        static void Main(string[] args)
        {
            #region String de conexão
            string connectionString = @"Server=xxxxx.database.windows.net,1433;
                                        Initial Catalog=xxxxxxxx-dev;
                                        Persist Security Info=False;
                                        User ID=xxxxxxxxxxx;
                                        Password=xxxxxxxxxx;
                                        MultipleActiveResultSets=False;
                                        Encrypt=True;
                                        TrustServerCertificate=False;
                                        Connection Timeout=90";
            #endregion

            AccountRepository accountRepository = new (connectionString);
            DataTable accountsTable = accountRepository.GetAccounts();
            DataTable positionTable = accountRepository.GetPosition();

            #region Realização de consulta
            var queryAll = from acc in accountsTable.AsEnumerable()
                                   select acc;

            foreach (DataRow row in queryAll)
            {  
                Console.WriteLine("Nome do usuário: " + (string)row["Name"]
                                + " Email do usuário: " + (string)row["Email"]
                                + " Matrícula: " + (string)row["EmployeeId"]);
            }           

            Console.ReadKey();
            #endregion

            #region Aplicação de filtro
 
            DateTime currentDate = DateTime.Now;
            
            int currentMonth = currentDate.Month;

            var queryAllFilters = from accF in accountsTable.AsEnumerable()
                                  where (accF["EmployeeId"].Equals("123456") || (string)accF["EmployeeId"] != "663008") 
                                 // && (bool)accF["Active"] == true
                                  && ((DateTime)accF["AdmissionDate"]).Month == currentMonth
                                  && (((string)accF["Name"]).Contains("Jeff")|| ((string)accF["Name"]).Contains("mento"))
                                  select accF;

            Account accountFilter = new();
            foreach (DataRow row in queryAllFilters)
            {
                accountFilter.Name = (string) row["Name"];
                accountFilter.Email = (string) row["Email"];
                accountFilter.EmployeeId = (string) row["EmployeeId"];

                Console.WriteLine(" Nome do usuário filtrado: " + accountFilter.Name
                                + " Email do usuário: " + accountFilter.Email
                                + " Matrícula: " + accountFilter.EmployeeId);
            }
            Console.ReadKey();
            #endregion
           
            #region Ordenação
             var queryAllO = from accO in accountsTable.AsEnumerable()
                            orderby accO["EmployeeId"] ascending, accO["Email"] descending
                             select accO;

            Account accountO = new();
            foreach (DataRow row in queryAllO)
            {
                accountO.Name = (string)row["Name"];
                accountO.Email = (string)row["Email"];
                accountO.EmployeeId = (string)row["EmployeeId"];

                Console.WriteLine(" Nome do usuário ordenado: " + accountO.Name
                                + " Email do usuário: " + accountO.Email
                                + " Matrícula: " + accountO.EmployeeId);
            }
            Console.ReadKey();
            #endregion

            #region Agrupamento
            var queryAllAGR = from accAG in accountsTable.AsEnumerable()
                              group accAG by accAG["EmployeeId"];

            foreach (var group in queryAllAGR)
            {
                // Percorra todos os registros agrupados para o employeeId atual
                foreach (var row in group)
                {

                    Console.WriteLine($"EmployeeId:" + row["EmployeeId"].ToString(), " Nome :" + row["Name"].ToString());
                }
            }

            
            Console.ReadKey();
            #endregion

            #region Adição (join)
            var innerJoinQuery =
              from acc in accountsTable.AsEnumerable()
              join pos in positionTable.AsEnumerable() on acc["PositionId"] equals pos["Id"]
              select new { Usuario = acc["Name"], PositionName = pos["Name"], Email = acc["Email"] };

            foreach (var result in innerJoinQuery)
            {
                string usuario = result.Usuario.ToString();
                string positionName = result.PositionName.ToString();
                string email = result.Email.ToString();

                // Faça o que desejar com os valores obtidos
                Console.WriteLine($"Usuário: {usuario}, PositionName: {positionName}, Email: {email}");
            }

            Console.ReadKey();
           #endregion
           
        }
    }

    public class Account
    {
        public int Id { get; set; }
        public   int PositionId { get; set; }
        public string Name { get; set; }
        public string EmployeeId { get; set; }
        public string Email { get; set; }
        public DateTime AdmissionDate { get; set; }    
        public bool Active { get; set; }
    }

    public class Position
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }
        public DateTime Created { get; set; }
    }

    public class AccountPosition
    {
        public string Usuario { get; set; }
        public string PositionName { get; set; }
        public string Email { get; set; }
    }

    public class AccountRepository
    {
        private string connectionString;

        public AccountRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public DataTable GetAccounts()
        {
            DataTable accountsTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT  PositionId, Name, EmployeeId, AdmissionDate, Email FROM RPAAccount";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    adapter.Fill(accountsTable);
                }
            }

            return accountsTable;
        }

        public DataTable GetPosition()
        {
            DataTable positionTable = new ();

            using (SqlConnection connection = new(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Position";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    adapter.Fill(positionTable);
                }
            }

            return positionTable;
        }
    }
}
